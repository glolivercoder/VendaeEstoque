<?php
// Silêncio é dourado.
// Este arquivo existe para evitar a listagem de diretórios.
